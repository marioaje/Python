# print( 1 > 2 ) #false porque el 1 no es mayor

# print( 1 < 2 )

#resultado = 1 < 2  #true porque el 2 es mayor
#resultado = 1 == 2  #verifica que si los datos son iguales
#resultado = 1 != 2  #verifica que si los datos son diferentes
#resultado = "Texto" == "texto"
# resultado = "Texto" == "Texto"
# print( resultado )#true porque el 2 es mayor


# #mariposa hacia el tubo a + llave del tubo a
#Compuerta Logica u Operador Logico
#Operador and, es evaluar cada uno de sus extremos
#para verficar que ambos sean valores verdaderos

resultado = (1<11) and (21==2)
#Un and de como resultado true, ambos extremos deben ser true
print( resultado )

resultado = True and True
print("True and True")
print( resultado )

print(" True and False")
resultado = True and False
print( resultado )

print ("Login y password")
resultado = ("password" == "password") and ("correo"=="correo")
print( resultado )


#Compuerta Logica u Operador Logico
#Operador OR, es evaluar cada uno de sus extremos
#para verficar que uno sea verdadero

resultado = (1!=1) or (2!=2)
print ( "(1==1) or (2!=2)")
print(resultado)