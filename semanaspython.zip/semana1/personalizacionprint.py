valora = input("Ingrese su texto: ")
valorb = input("Su nombre: ")

print ( valora + "\"-\"" + valorb)
print ( valora + ' ' + valorb)
print ( valora, valorb)