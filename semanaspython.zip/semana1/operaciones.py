#30 manzanas + 15 manzanas
# variablea = 30
# variableb = 15
# resultado = variablea + variableb
# print( "La suma de", variablea, "+", variableb, "=" ,resultado, "manzanas" )

# resultado = variablea - variableb
# print( "La resta de", variablea, "-", variableb, "=" ,resultado, "manzanas" )

#captura el valor del teclado
#y lo asigna a una variable en este caso se 
#llama dato1
dato1 = input("Ingresa cualquier valor1: ")
dato2 = input("Ingresa cualquier valor2: ")
dato3 = int(input("Ingresa cualquier valor3: "))
#hablo acerca de lenguage no tipado
dato1= int(dato1)
dato2= int(dato2)

resultado = dato1 + dato2 + dato3

print("El usuario ingreso:", resultado)


#Profesor, similar a la linea 5
#Capturar dos valores y sumarlos + entre ellos, adicionale que se muestre el mensaje del resultado de la operacion
#Capturar dos valores y restarlos - entre ellos, adicionale que se muestre el mensaje del resultado de la operacion
#Capturar dos valores y multiplicarlos * entre ellos, adicionale que se muestre el mensaje del resultado de la operacion
#Capturar dos valores y dividirlos / entre ellos, adicionale que se muestre el mensaje del resultado de la operacion
