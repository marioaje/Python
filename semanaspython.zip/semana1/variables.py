import os
os.system('cls')

#Una variable es algo o un valor que puede cambiar en el tiempo
valora = 908
#Imprime lo que esta en el parentesis
print(valora)
#los lenguajes tipados requieren saber que tipo de datos es
valora = 908 #cualquier numero
decimales = 10.1 #Cualquier numero con decimales
nombre = "Mario" #Cualquier texto
confirmacion = True #Tipos booleans False o True
print( valora)
print( decimales)
print( nombre )
print( confirmacion)

#Variables tipados
#int valora = 908 #cualquier numero
#double decimales = 10.1 #Cualquier numero con decimales
#string nombre = "Mario" #Cualquier texto
#boolean confirmacion = True #Tipos booleans False o True
