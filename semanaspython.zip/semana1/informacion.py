#Importar una libreria de systema
import sys

#Print sirve para imprimir informacion
print(sys.version[0])