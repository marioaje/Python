def mostrarmenu():
    return "Soy un menu"

def mostrarmenu2():
    return "Soy un menu 2"

def mostrarmenu3():
    return "Soy un menu3"



class Menu:
    def __init__(self):
        self.dato = ""
