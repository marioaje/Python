class nuevomenus:
    def __init__(self):
        print("estoy en nuevomenus")

    def mostrarnuevomenus():
        return "Soy un menu nuevomenus"