def saludos():
    print("Saludos")

def menuprincipal():
    while ( Opcion != 0 ):
        print ( "Estoy dentro")
        Opcion = int( input("Ingrese 0 para salir o 1 para continuar") )    