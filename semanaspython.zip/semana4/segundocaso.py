import plantillamenu

print(plantillamenu.mostrarmenu())