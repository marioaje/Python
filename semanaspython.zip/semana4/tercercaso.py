import nuevomenus

crearvariable = nuevomenus.nuevomenus()
