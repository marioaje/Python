#Sele conoce como librerias(Son class), modulos (Clases), funciones

from plantillamenu import mostrarmenu
from funciones import *
import nuevomenus

saludos()
print(mostrarmenu())
testdevariable = nuevomenus.nuevomenus()

#en el principal creo la intterfaz grafica.