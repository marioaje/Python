#funcion sin parametros o argumentos
def imprimeMensaje():
    print("Mensaje de bienvenida")

#funcion de mensaje con parametro
def imprimeMensajePersonalizado(textoMensaje):
    print(textoMensaje)

#funcion de mensaje con parametro
def imprimeMensajePersonalizados(textoMensaje, test):
    print(textoMensaje)    

#funcion que retorna datos
def funcionRetorno():
    return 3+3

def cualquiera():
    return 6+6


# imprimeMensaje()
# variable = "Hola clase"
# imprimeMensajePersonalizado(variable)

variable = funcionRetorno()
print(variable)