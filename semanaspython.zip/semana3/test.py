from clases import clases

variablea = clases("123", "Mario", "Jimenez")
variablea