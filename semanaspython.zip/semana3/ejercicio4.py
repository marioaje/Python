#Crear una calculadora, con funciones de sumar, resta, multiplicar, division, potencia
#les va a preguntar que desea hacer?
# 1-sumar
# 2-restar
# 3-multiplicar
# 4-dividir
# 0-Finalizar calculadora while

#Elaborar un programa que permita ingresar 100(for) número enteros y muestre la cantidad de números pares e impares ingresados.


#Mostrar los 15 primeros elementos de la serie Fibonacci:
#0 , 1 , 1 , 2 , 3 , 5 , 8 , 13 , 21 , 34, ...

#Todos los ejercicios deben crear con funciones
#Realizar un algoritmo que visualice la siguiente progresión aritmética:
#1 , 5 , 7 , 10 , 13 , 15 , 19 , 20 , 25 , 25.
#1, 2, 3, 4, 5, 6, 7 +1
#,1,3,5,7,9,11 +2
#,1,4,7,10 +3
#(3, 6, 0, 30)
#0 3 9 12 18 21 27 30 ---36
#+3, +6, +3, +6, 
#while, if, input, variables, una funcion o dos, print


