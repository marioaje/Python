# #validacion de un ciclo, siempre que cumpla la condicion
# contador = 0

# #Mientras, do while
# while ( contador < 10 ):
#     print ("Numero de secuencia", contador)
#     contador += 1
#     #contador = contador + 1

# verificar = 0
# #Mientras, do while
# while ( verificar == 0 ):
#     print ("Numero de secuencia", verificar)
#    # input("desea salir, ingrese el numero 1")
#     verificar = 1
#     #contador = contador + 1

condicion = -100
while (condicion <= 333):
    print(condicion)
    condicion += 1