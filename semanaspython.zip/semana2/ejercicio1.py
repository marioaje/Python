ejercicio1 = """
Una persona tiene $100.000 y decide invertir $70.000
en bonos hipotecarios a un 5% (mensual)
y el resto en un depósito a plazo a 10% (mensual).
¿Cuánto dinero ganará esta persona después de un mes?
"""

#70000 + 5%
#2 mes (70000 + 5%) +5 %
#3 mes

ejercicio2 = """
Usted va a hacer compras por 12000 colones en un comercio 
y el vendedor le ofrece un descuento de 1000 colones,
 demuestre como sería más barato el precio final,
   si primero le aplican el descuento y 
   luego le cobran el 13% de impuesto o que primero 
   le carguen el 13% de impuesto y
     luego le hagan el descuento.
"""

#12000-1000
#12000-1000 * +.13 ( hagan una peque formula cual les de 0.13) numero de impuesto/100
#12000 * +.13 - 1000

print(ejercicio1.upper())


ejercicio3 = """
Escriba un algoritmo que lea dos valores,
 determine el mayor valor e imprima el mayor
   valor con un mensaje de identificación.
"""
#ocupo inputs
#y los comparo con el operador

ejercio4 = """
Escriba un algoritmo que lea los siguientes valores: 
precio, impuesto y descuento, 
y calcule el valor total de la factura.
"""
#cuantos inputs? 3
#resultado 15400 ??? no tiene el iva, y no tiene el descuento.
#resultado - descuennto, al final se le aplica el iva


ejercio5 = """
Escriba un algoritmo que permita leer el sexo 
y la edad de una persona dada e imprima si la 
persona está en edad de pensionarse o no,
 tomando en cuenta los siguientes datos:
Hombres: edad de pensión mayor de 65 años.
Mujeres: edad de pensión mayor a 62 años.

"""

numero = 6

muestra = f""" {numero}
Usted va a hacer compras por 12000 colones en un comercio 
y el vendedor le ofrece un descuento de 1000 colones,
 demuestre como sería más barato el precio final,
   si primero le aplican el descuento y 
   luego le cobran el 13% de impuesto o que primero 
   le carguen el 13% de impuesto y
     luego le hagan el descuento.
"""

print(muestra)