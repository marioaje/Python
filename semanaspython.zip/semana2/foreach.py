#foreach, permite recorrer una lista que desconozcamos sus valores
mylista = ['mario', "Jimenez", 44, 10.1, True]

for item in mylista:
    print("Key o elemento de la lista", item)