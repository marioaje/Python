import os
#os.rmdir("test")

os.mkdir("Creadocarpeta")
os.